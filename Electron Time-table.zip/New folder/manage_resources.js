const apiUrl = 'http://localhost:3000'; // Update as necessary

async function addRoom() {
    const roomName = document.getElementById('roomName').value;
    // Logic to send the roomName to your backend
    await fetch(`${apiUrl}/admin/addRoom`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: roomName }),
    });
}

async function addModule() {
    const moduleName = document.getElementById('moduleName').value;
    // Logic to send the moduleName to your backend
    await fetch(`${apiUrl}/admin/addModule`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: moduleName }),
    });
}

async function addBatch() {
    const batchName = document.getElementById('batchName').value;
    // Logic to send the batchName to your backend
    await fetch(`${apiUrl}/admin/addBatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: batchName }),
    });
}

async function createTimetable() {
    // Logic to create timetable automatically
    await fetch(`${apiUrl}/admin/createTimetable`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}), // Pass any necessary data
    });
}
