const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// Load the database
let database = JSON.parse(fs.readFileSync('database.json', 'utf8'));

// Function to save the database
const saveDatabase = () => {
    fs.writeFileSync('database.json', JSON.stringify(database, null, 2));
};

// API route for student registration
app.post('/register/student', (req, res) => {
    const { name, password, course } = req.body;

    if (!name || !password || !course) {
        return res.status(400).send('Missing required fields');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    if (database.students && database.students[lowerCaseName]) {
        return res.status(400).send('Student already exists');
    }

    // Add student to the database
    database.students = database.students || {};  // Ensure students object exists
    database.students[lowerCaseName] = {
        password: password,
        course: course,
        role: 'student',
        timetable: []
    };

    saveDatabase();
    res.status(200).send('Student registered successfully');
});

// API route for lecturer registration
app.post('/register/lecturer', (req, res) => {
    const { name, password } = req.body;

    if (!name || !password) {
        return res.status(400).send('Missing required fields');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    if (database.lecturers && database.lecturers[lowerCaseName]) {
        return res.status(400).send('Lecturer already exists');
    }

    // Add lecturer to the database
    database.lecturers = database.lecturers || {};  // Ensure lecturers object exists
    database.lecturers[lowerCaseName] = {
        password: password,
        role: 'lecturer',
        batches: []
    };

    saveDatabase();
    res.status(200).send('Lecturer registered successfully');
});

// API route for login
app.post('/login', (req, res) => {
    const { name, password } = req.body;

    if (!name || !password) {
        return res.status(400).send('Missing username or password');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    // Check if user is an admin
    if (database.users && database.users[lowerCaseName] && database.users[lowerCaseName].password === password) {
        return res.json({ role: 'admin' });
    }

    // Check if user is a student
    if (database.students && database.students[lowerCaseName] && database.students[lowerCaseName].password === password) {
        return res.json({ role: 'student' });
    }

    // Check if user is a lecturer
    if (database.lecturers && database.lecturers[lowerCaseName] && database.lecturers[lowerCaseName].password === password) {
        return res.json({ role: 'lecturer' });
    }

    res.status(400).send('Invalid username or password');
});

// API route for viewing all users (students and lecturers)
app.get('/admin/viewUsers', (req, res) => {
    const users = {
        students: Object.keys(database.students).map(key => ({
            username: key,
            course: database.students[key].course,
        })),
        lecturers: Object.keys(database.lecturers).map(key => ({
            username: key,
            batches: database.lecturers[key].batches,
        })),
    };
    res.json(users);
});

// API route for deleting a student
app.delete('/admin/deleteStudent', (req, res) => {
    const { name } = req.body;

    console.log('Received student name:', name); // Log the received name

    if (!name) {
        return res.status(400).send('Name missing');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    if (!database.students || !database.students[lowerCaseName]) {
        return res.status(404).send('Student not found');
    }

    // Delete the student from the database
    delete database.students[lowerCaseName];
    saveDatabase();

    res.send('Student deleted successfully');
});

// API route for deleting a lecturer
app.delete('/admin/deleteLecturer', (req, res) => {
    const { name } = req.body;

    console.log('Received lecturer name:', name); // Log the received name

    if (!name) {
        return res.status(400).send('Name missing');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    if (!database.lecturers || !database.lecturers[lowerCaseName]) {
        return res.status(404).send('Lecturer not found');
    }

    // Delete the lecturer from the database
    delete database.lecturers[lowerCaseName];
    saveDatabase();

    res.send('Lecturer deleted successfully');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});


// API route for adding a lecture room
app.post('/admin/addRoom', (req, res) => {
    const { name } = req.body;
    database.rooms = database.rooms || {};
    database.rooms[name.toLowerCase()] = { name };
    saveDatabase();
    res.send('Room added successfully');
});

// API route for adding a module
app.post('/admin/addModule', (req, res) => {
    const { name } = req.body;
    database.modules = database.modules || {};
    database.modules[name.toLowerCase()] = { name };
    saveDatabase();
    res.send('Module added successfully');
});

// API route for adding a batch
app.post('/admin/addBatch', (req, res) => {
    const { name } = req.body;
    database.batches = database.batches || {};
    database.batches[name.toLowerCase()] = { name };
    saveDatabase();
    res.send('Batch added successfully');
});

// API route for creating the timetable
app.post('/admin/createTimetable', (req, res) => {
    // Logic to create the timetable without overlaps
    // (Implement your own algorithm here)
    res.send('Timetable created successfully');
});


// API route for getting a student's timetable
app.get('/timetable/student/:username', (req, res) => {
    const username = req.params.username.toLowerCase();

    if (!database.students || !database.students[username]) {
        return res.status(404).send('Student not found');
    }

    const timetable = database.students[username].timetable; // Retrieve the student's timetable
    res.json(timetable);
});

// API route for getting a lecturer's classes
app.get('/timetable/lecturer/:username', (req, res) => {
    const username = req.params.username.toLowerCase();

    if (!database.lecturers || !database.lecturers[username]) {
        return res.status(404).send('Lecturer not found');
    }

    const classes = database.lecturers[username].batches; // Retrieve the classes the lecturer teaches
    res.json(classes);
});


// API route for creating the timetable
app.post('/admin/createTimetable', (req, res) => {
    const timetableData = {
        "BSC": [
            { day: 'Monday', time: '10:00 - 11:00', subject: '351 CS 23', classroom: 'LH2' },
            { day: 'Tuesday', time: '11:00 - 12:00', subject: '323 OD 21', classroom: 'LAB 2' },
            // Additional BSC timetables...
        ],
        "CCC": [
            { day: 'Monday', time: '09:00 - 10:00', subject: '123 CS 45', classroom: 'LH1' },
            // Additional CCC timetables...
        ],
        // More courses...
    };

    // Assign the timetable to each student based on their course
    for (const studentName in database.students) {
        const student = database.students[studentName];
        if (timetableData[student.course]) {
            student.timetable = timetableData[student.course]; // Assign timetable based on course
        }
    }

    saveDatabase();
    res.send('Timetable created successfully');
});

// API route for getting a student's timetable
app.get('/timetable/student/:username', (req, res) => {
    const username = req.params.username.toLowerCase();

    if (!database.students || !database.students[username]) {
        return res.status(404).send('Student not found');
    }

    const timetable = database.students[username].timetable; // Retrieve the student's timetable
    res.json(timetable);
});

// API route for getting a lecturer's classes
app.get('/timetable/lecturer/:username', (req, res) => {
    const username = req.params.username.toLowerCase();

    if (!database.lecturers || !database.lecturers[username]) {
        return res.status(404).send('Lecturer not found');
    }

    const classes = database.lecturers[username].batches; // Retrieve the classes the lecturer teaches
    res.json(classes);
});
